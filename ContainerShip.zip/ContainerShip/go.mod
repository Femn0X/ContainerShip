module containership

go 1.21

require(
    github.com/docker/docker v25.0.3+incompatible
    gopkg.in/yaml.v2 v2.4.0
)