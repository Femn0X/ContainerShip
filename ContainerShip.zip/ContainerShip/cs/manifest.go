package cs
import(
 "gopkg.in/yaml.v2"
 "io/ioutil"
)
type Service struct{
 Image string `yaml:"image"`
 DependsOn []string `yaml:"depends_on"`
 Ports []string `yaml:"ports,omitempty"`
 Enviroment map[string]string `yaml:"enviroment,omitempty"`
}
type Manifest struct{
 Version string `yaml:"version"`
 Services map[string]Service `yaml:"services"`
}
func LoadManifest(path string)(*Manifest,error){
 data,err:=ioutil.ReadFile(path)
 if err!=nil{
  return nil,err
 }
 var manifest Manifest
 err=yaml.Unmarshal(data,&manifest)
 if err!=nil{
  return nil,err
 }
 return &manifest,nil
}
