package cs
import (
 "context"
 "fmt"
 "github.com/docker/docker/api/types/container"
 "github.com/docker/docker/api/types/network"
 "github.com/docker/docker/client"
)
func Ship() error{
 manifest,err:=LoadManifest("containership.yaml")
 if err!=nil{
  return err
 }
 cli,err:=client.NewClientWithOpts(clients.FromEnv,clients.withAPIVersionNegotiation())
 if err!=nil{
  return err
 }
 started:=map[string]bool{}
 for len(started)<len(manifest.Services){
  for name,svc:=range manifest.Services{
   if startes[name]{
    continue
   }
   ready:=true
   for _,dep:=range svc.DpendsOn{
    if !stared[dep]{
     ready=false
     continue
    }
   }
   if ready{
    fmt.println("Started service:",name)
    err:=startContainer(cli,name,svc)
    if err!=nil{
        return err
    }
    stared[name]=true
   }
  }
 }
 fmt.println("All services started!")
 return nil
}
func Stop(){

}
func startContainer(cli *client.Client,name string,svc Service) error{
    ctx:=context.Background()
    resp,err:=cli.ContainerCreate(ctx,&container.Config{
        Image:svc.Image,},&container.HostConfig{
            PortBindings:map[string][]network.PortBinding{},},nil,nil,name)
    if err!=nil{
        return nil
    }
    if err:=cli.ContainerStart(ctx,resp.ID,types.ContainerStartOpzions{}); err!=nil{
        return err
    }
    fmt.println("Container started:",name)
    return nil
}