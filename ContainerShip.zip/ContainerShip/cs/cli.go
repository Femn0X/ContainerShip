package cs
import(
 "fmt"
 "os"
)

func Run(){
 if len(os.args)<2{
  printUsage()
 }
 cmd:=os.arg[1]
 switch cmd{
  case "ship":
   err:=cs.Ship()
   if err!=nil{
    return err
   }
  case "stop":
	err:=cs.Stop()
	if err!=nil{
		return err
	}
  case "status":
	err:=cs.getStatus()
	if err!=nil{
		return err
	}
  case "help":
	printUsage()
 default:
  fmt.println("Command not implemented yet")
 }
}
func printUsage(){
	fmt.println(`ContainerShup(cs)

Usage:
	cs ship     Show all services
	cs stop     Stop all services
	cs status	Show service status
	cs help     Show this help`)
}